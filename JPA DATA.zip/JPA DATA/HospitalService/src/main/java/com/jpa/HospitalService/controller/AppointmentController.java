package com.jpa.HospitalService.controller;

import org.springframework.beans.factory.annotation.Autowired;

import com.jpa.HospitalService.entity.Appointment;
import com.jpa.HospitalService.service.AppointmentService;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/hospital")
public class AppointmentController {
	
	@Autowired
	private AppointmentService appointmentService;
	
	@PostMapping("/createAppointment/{d_id}/{p_id}")
	public Appointment createAppointment(@RequestBody Appointment appointment, @PathVariable Integer d_id, @PathVariable Integer p_id) {
		return appointmentService.createAppointment(appointment, d_id, p_id);
	}
}
