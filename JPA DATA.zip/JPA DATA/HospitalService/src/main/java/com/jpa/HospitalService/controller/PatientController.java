package com.jpa.HospitalService.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jpa.HospitalService.entity.Insurance;
import com.jpa.HospitalService.entity.Patient;
import com.jpa.HospitalService.service.PatientService;

@RestController
@RequestMapping("/hospital")
public class PatientController {
	
	@Autowired
	private PatientService patientService;
	
	@PostMapping("/addInsurance/{id}")
	public Patient addInsurance(@RequestBody Insurance insurance, @PathVariable Integer id) {
		return patientService.addInsurance(insurance, id);
	}
	
	@PostMapping("/deleteInsurance/{id}")
	public Patient deleteInsurance(@PathVariable Integer id) {
		return patientService.deleteInsurance(id);
	}
}
