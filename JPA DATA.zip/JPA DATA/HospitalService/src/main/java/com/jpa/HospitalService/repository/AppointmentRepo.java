package com.jpa.HospitalService.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jpa.HospitalService.entity.Appointment;

public interface AppointmentRepo extends JpaRepository<Appointment, Integer>{

}
