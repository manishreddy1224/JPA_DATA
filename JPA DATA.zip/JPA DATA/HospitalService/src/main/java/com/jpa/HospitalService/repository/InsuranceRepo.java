package com.jpa.HospitalService.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.jpa.HospitalService.entity.Insurance;

@Repository
public interface InsuranceRepo extends JpaRepository<Insurance, Integer>{

}
