package com.jpa.HospitalService.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jpa.HospitalService.entity.Appointment;
import com.jpa.HospitalService.entity.Doctor;
import com.jpa.HospitalService.entity.Patient;
import com.jpa.HospitalService.repository.AppointmentRepo;
import com.jpa.HospitalService.repository.DoctorRepo;
import com.jpa.HospitalService.repository.PatientRepo;

@Service
public class AppointmentService {
	
	@Autowired
	private AppointmentRepo appointmentRepo;
	
	@Autowired
	private DoctorRepo doctorRepo;
	
	@Autowired
	private PatientRepo patientRepo;
	
	public Appointment createAppointment(Appointment appointment, Integer d_id, Integer p_id) {
		Optional<Doctor> option= doctorRepo.findById(d_id);
		Optional<Patient> option1 = patientRepo.findById(p_id);
		if(option.isPresent() && option1.isPresent()) {
			appointment.setDoctor(option.get());
			appointment.setPatient(option1.get());
			appointmentRepo.save(appointment);
			return appointment;
		}else {
		return null;
		}
	}
}
