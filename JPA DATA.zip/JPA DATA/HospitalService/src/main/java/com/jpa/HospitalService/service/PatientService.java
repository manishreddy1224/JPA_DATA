package com.jpa.HospitalService.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jpa.HospitalService.entity.Insurance;
import com.jpa.HospitalService.entity.Patient;
import com.jpa.HospitalService.repository.PatientRepo;

import jakarta.transaction.Transactional;

@Service
public class PatientService {
	
	@Autowired
	private PatientRepo patientRepo;
	
	
	
	public Patient addInsurance(Insurance insurance, Integer id) {
		Optional<Patient> option = patientRepo.findById(id);
		if(option.isPresent()) {
			Patient patient = option.get();
			patient.setInsurance(insurance);
			patientRepo.save(patient);
			return patient;
		}
		else {
			return null;
		}
	}
	
	@Transactional
	public Patient deleteInsurance(Integer id) {
		Optional<Patient> option = patientRepo.findById(id);
		if(option.isPresent()) {
			Patient patient = option.get();
			patient.setInsurance(null);
			return patient;
		}
		else {
			return null;
		}
	}
	
}
